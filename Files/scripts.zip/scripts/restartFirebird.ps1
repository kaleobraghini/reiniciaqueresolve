# Verifica se está rodando como Administrador
$admin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

if (-not $admin) {
    Write-Host "Este script precisa ser executado como ADMINISTRADOR!" -ForegroundColor Red
    exit
}

# Reiniciar Firebird

$nomeServico = "FirebirdServerDefaultInstance"

Write-Host "============================================="
Write-Host "     Gerenciamento do Servico Firebird"
Write-Host "============================================="
Write-Host ""

# Verifica se o serviço existe
$servico = Get-Service -Name $nomeServico -ErrorAction SilentlyContinue

if ($null -eq $servico) {
    Write-Host "[ERRO] Servico '$nomeServico' nao encontrado no sistema." -ForegroundColor Red
} else {
    Write-Host "Servico encontrado: $($servico.DisplayName)"
    Write-Host "Status atual: $($servico.Status)"
    Write-Host ""

    if ($servico.Status -eq 'Running') {
        Write-Host "O servico esta rodando. Reiniciando..."
        try {
            Restart-Service -Name $nomeServico -Force -ErrorAction Stop
            Write-Host "[SUCESSO] Servico reiniciado com sucesso." -ForegroundColor Green
        } catch {
            Write-Host "[ERRO] Falha ao reiniciar o servico." -ForegroundColor Red
        }
    } elseif ($servico.Status -eq 'Stopped') {
        Write-Host "O servico esta parado. Iniciando..."
        try {
            Start-Service -Name $nomeServico -ErrorAction Stop
            Write-Host "[SUCESSO] Servico iniciado com sucesso." -ForegroundColor Green
        } catch {
            Write-Host "[ERRO] Falha ao iniciar o servico." -ForegroundColor Red
        }
    } else {
        Write-Host "[AVISO] O servico está no estado '$($servico.Status)'. Nenhuma ação tomada." -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "============================================="
Write-Host "Processo concluido."
Write-Host "============================================="
Write-Host ""
Read-Host -Prompt "Pressione Enter para sair"
