# Verificar se está rodando como Administrador
$admin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

if (-not $admin) {
    Write-Host "Este script precisa ser executado como ADMINISTRADOR!" -ForegroundColor Red
    Read-Host -Prompt "Pressione Enter para sair"
    exit
}

Write-Host "============================================="
Write-Host "Liberacao de portas Firebird"
Write-Host "============================================="
Write-Host ""

# Definições das regras
$Regras = @(
    @{ Nome = "Firebird 3050"; Porta = 3050 },
    @{ Nome = "Firebird 3051"; Porta = 3051 }
)

foreach ($regra in $Regras) {
    Write-Host "---------------------------------------------"
    Write-Host "Verificando regra '$($regra.Nome)' na porta $($regra.Porta)..."

    $existe = Get-NetFirewallRule -DisplayName $regra.Nome -ErrorAction SilentlyContinue

    if ($null -ne $existe) {
        Write-Host "Regra '$($regra.Nome)' ja existe." -ForegroundColor Green
    } else {
        Write-Host "Criando regra '$($regra.Nome)' para a porta $($regra.Porta)..."
        try {
            New-NetFirewallRule -DisplayName $regra.Nome `
                                -Direction Inbound `
                                -LocalPort $regra.Porta `
                                -Protocol TCP `
                                -Action Allow `
                                -Profile Any `
                                -ErrorAction Stop

            Write-Host "Regra '$($regra.Nome)' criada com sucesso." -ForegroundColor Green
        } catch {
            Write-Host "Erro ao criar a regra '$($regra.Nome)': $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

Write-Host ""
Write-Host "============================================="
Write-Host "Processo de configuração concluido!"
Write-Host "============================================="
Write-Host ""
Read-Host -Prompt "Pressione Enter para sair"
