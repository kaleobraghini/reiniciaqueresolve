# Definir pasta de logs em caminho especifico
$logFolder = "C:\HMAX-Suporte\AdminTools\logs"
if (-not (Test-Path -Path $logFolder)) {
    New-Item -Path $logFolder -ItemType Directory | Out-Null
}

# Entrada do usuario
$destino = Read-Host "Digite o IP ou Hostname"

# Definir caminho e nome do arquivo de log
$logFile = Join-Path -Path $logFolder -ChildPath "log_ping-$destino.txt"

Write-Host "Iniciando ping para $destino. Logs serao salvos em $logFile"
Write-Host "Pressione Ctrl + C para parar..."

# Loop de ping continuo
while ($true) {
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    try {
        $result = Test-Connection -ComputerName $destino -Count 1 -ErrorAction Stop
        $output = "$timestamp - Resposta de $($result.Address) - Tempo: $($result.ResponseTime)ms"
    } catch {
        $output = "$timestamp - Sem resposta de $destino"
    }

    # Mostrar no console
    Write-Host $output

    # Escrever no log
    Add-Content -Path $logFile -Value $output

    Start-Sleep -Seconds 1
}
